<template>
    <div id="app">
        <!-- 图片预加载,需要改成ws链接,具体问涛哥 -->
        <div id="load2">
            <!-- <img src="https://img.chiruan.net/vueCode/qinding/lianxiang5g/static/img/title1.png" hidden/> -->
        </div>

        <!-- 案例 -->
        <AnLi v-show="$store.state.dataInfo.project && $store.state.dataInfo.project.is_case"/>

 

        <!-- 中间内容 -->
        <Home v-if="$store.state.idx == 1"/>
        <Txxingxi v-else-if="$store.state.idx == 2"/>
        <choujiang v-else-if="$store.state.idx == 3"/>
        <!-- <a href="javascript:;" class="bgm" :class="bf" @click="bofang">
            <img src="./assets/image/music_icon.png">
        </a> -->
    </div>
</template>

<script>
    import Home from "./components/Home"
    import choujiang from './components/choujiang' 
    import Txxingxi from './components/Txxingxi'
import { type } from 'os'

    export default {
        //定义数据
        data() {
            return {
                // bf: "",
                // yy: null
            }
        },

        //组件引入
        components: {
            Home,
            choujiang,
            Txxingxi
        },

        //自定义方法
        methods: {
            dengdai(){
                // 测试跳转
                // let _jz   = document.getElementById('jiaZai');
                // let _load = document.getElementById('load2');

                // if(_jz) _jz.remove();
                // if(_load) _load.remove();

                // this.$store.state.idx = 1;
                // return;
                
                //正式跳转
                if(this.$store.state.dataInfo.wx_info){
                    let _jz   = document.getElementById('jiaZai');
                    let _load = document.getElementById('load2');
                    if(_jz) _jz.remove();
                    if(_load) _load.remove();
                    this.$store.state.idx = 1;
                }else{
                    setTimeout(()=>{
                        this.dengdai();
                    },160)
                }
            },
            //头像
            // tx(id){
            //     this.cr.ajax({
            //         curl: 'https://www.chiruan.net/image/headImgUrl',
            //         data: {
            //             project_id: id
            //         },
            //         fn: (res)=> {
            //             if (res.code != 1) return;
            //             this.$store.state.wxtx = res.data;
            //         }
            //     })
            // },
            //数据
            sj(){
                this.$store.commit('xdata',(_data)=>{
                    //头像
                    //this.tx(_data.project.id);

                    this.cr.share({
                        wxId     : _data.wx_info.id,
                        projectId: _data.project.id,
                        fn: (res)=>{
                            // if(this.$store.state.dataInfo.share_count < 1){
                            //     this.$store.commit('xdata',()=>{});
                            // }
                        }
                    })
                });
            },
            // shijian(s){
            //     let _t = Math.floor(s / 86400);
            //     let _s = Math.floor((s % 86400) / 3600);
            //     let _f = Math.floor(((s % 86400) % 3600) / 60);
            //     //let _m = Math.floor(((s % 86400) % 3600) % 60);

            //     this.$store.state.sj = _t+"天"+_s+"小时"+_f+"分钟";
            // }
            //音乐加载
            // audio: function(){
            //     let $audio = new Audio();

            //     document.addEventListener("WeixinJSBridgeReady", ()=> {//微信
            //         $audio.loop = true;
            //         this.yy = $audio;
            //         $audio.play();
            //         this.bf = "play";
            //     }, false);
            //     $audio.onloadedmetadata = ()=>{
            //         $audio.loop = true;
            //         this.yy = $audio;
            //         $audio.play();
            //         this.bf = "play";
            //     };
           
            //     $audio.src = "https://img.chiruan.net/vueCode/qinding/lianxiang5g/static/media/bgm.mp3";
            // },
            // bofang(){
            //     if(!this.yy) return;

            //     if(this.yy.paused){ 
            //         this.yy.play();
            //         this.bf = "play";
            //     }else{
            //         this.yy.pause();
            //         this.bf = "";
            //     }
            // }
        },

        //在实例创建完成后被立即调用
        created(){
            //请求个人信息数据
            this.sj();
            //音乐
            //this.audio();
        },

        //添加真实dom，不一定所有的子组件也都一起被挂载才回调
        mounted(){
            this.cr.dingbu();
            window.onload = () =>{
                this.dengdai();
            }
        }
    };
</script>

<style lang="less">
    #app{
        background: #000;
    }
    #load2{
        position: absolute;
        top: -999px;
    }
</style>
