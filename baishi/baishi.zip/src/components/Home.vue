<template>
  <div id="home">
    <div ref="kuan" class="kuan"></div>
    <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/bg.png" class="zimu" />
    <div class="maxbox">
      <img src="../assets/image/baishilogo.png" />
      <div class="logo">
        <img src="../assets/image/logo.png" />
      </div>
      <div class="titleclass">
        <img src="../assets/image/title.png" />
      </div>
      <div class="yueqiu">
        <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/yuan.png" alt />
      </div>
      <div class="sekuai">
        <img src="../assets/image/kuai.png" alt />
      </div>
      <div class="xiaoyueqiu">
        <img src="../assets/image/2-qiu.png" alt />
      </div>
      <div class="woman" style="z-index:9">
        <img src="../assets/image/woman.png" alt />
      </div>
      <div class="man" style="z-index:9">
        <img src="../assets/image/man.png" alt />
      </div>
      <div class="keleclass" style="z-index:9">
        <img src="../assets/image/kele.png" alt />
      </div>
      <div class="bookclass">
        <img src="../assets/image/book.png" alt />
      </div>
      <div class="guangclass">
        <img src="../assets/image/guang.png" alt />
      </div>
      <div class="cy-btn" v-if="off" @click="changepage">
        <!-- $store.state.idx = 2; -->
        <img src="../assets/image/cy-btn.png" alt />
      </div>
      <div class="gz-btn" v-if="off" @click="gzclick">
        <img src="../assets/image/gz-btn.png" alt />
      </div>
      <div class="jp-btn" v-if="off" @click="jpclick">
        <img src="../assets/image/jp-btn.png" alt />
      </div>
      <div class="dibu">
        <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/dibu.png" alt />
      </div>
      <div class="heng2">
        <img src="../assets/image/heng2.png" alt />
      </div>
      <div class="src">
        <img src="../assets/image/weizhi.png" alt class="srcimg" />
        &nbsp;&nbsp;当前位置：&nbsp;
        <span class="mysrc">{{mysrc}}</span>
      </div>

      <!--奖品-->
      <div class="jp" v-if="jp_off">
        <div class="maxdiv">
          <ul class="maxjp">
            <li v-for="(item,index) in jpall" :key="index">
              <div class="jp_name">
                <img src="../assets/image/奖学金.png" v-if="item.prize =='奖学金'" />
                <img src="../assets/image/无糖树莓罐.png" v-else-if="item.prize =='无糖树莓罐'" />
                <img src="../assets/image/续杯.png" v-if="item.prize =='续杯'" />
                <img src="../assets/image/雪盐焦糖中瓶.png" v-if="item.prize =='雪盐焦糖中瓶'" />
                <img src="../assets/image/尊享卡.png" v-if="item.prize =='尊享卡'" />
              </div>
              <div class="jp_zt" v-if="item.over == 'n'">
                <p v-if="item.prize == '奖学金' && !item.card" @click="pzIdx = index;pz = 1;">上传凭证</p>
                <p
                  v-else-if="item.prize == '奖学金' && item.card"
                  style="color:#676767;border: 1px #676767 solid"
                >已传凭证</p>
                <p v-else-if="item.use != '核销'" @click="changelq(item.id)" :id="`${item.id}`">领取</p>
                <p v-else style="color:#676767;border: 1px #676767 solid">已领取</p>
              </div>
              <div class="jp_zt" v-else>
                <p style="color:#676767;border: 1px #676767 solid">已过期</p>
                <!-- <p v-else-if="item.prize == '奖学金' && item.card" style="color:#676767;border: 1px #676767 solid">已传凭证</p> -->
                <!-- <p v-else-if="item.use != '核销'" @click="changelq(item.id)" :id="`${item.id}`">领取</p>
                <p v-else style="color:#676767;border: 1px #676767 solid" >已领取</p>-->
              </div>
            </li>
          </ul>
        </div>
      </div>
      <!--返回首页-->
      <div class="fh-btn" v-if="jp_off" @click="fhclick">
        <img src="../assets/image/fh-btn.png" alt />
      </div>

      <!--规则-->
      <div class="gz" v-if="gz_off">
        <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/text2.png" />
      </div>
      <div class="fh-btn" v-if="gz_off" @click="fhclick">
        <img src="../assets/image/fh-btn.png" alt />
      </div>
    </div>
    <!-- <div>
              <img src="../assets/image/yuan.png" alt="" class="yuanclass">
        </div>    
        
        <div>
            <img src="../assets/image/man.png" alt="" class="thisman">    
    </div>-->

    <div class="pz" v-show="pz">
      <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/zj-jiangxuejin.png" alt class="jzjxj" />
      <van-cell-group class="vancell3">
        <van-field v-model="value3"  maxlength='11'/>
      </van-cell-group>
      <van-cell-group class="vancell4">
        <van-field v-model="value4"  maxlength='11'/>
      </van-cell-group>
      <div @click="bbb" class="flix">
        <img src="../assets/image/flix.png" v-if="!scImg" />
        <img :src="scImg" v-else />
      </div>
      <img src="../assets/image/btn-queding.png" alt class="jxj_quedingon" @click="jxj_quedingon" />
    </div>
  </div>
</template>

<script>
import Vue from "vue";
import { Toast } from "vant";
import { setTimeout } from "timers";
import { Dialog } from "vant";
Vue.use(Toast, Dialog);

export default {
  //定义数据
  data() {
    return {
      load: 0,
      pzIdx: "",
      scImg: "",
      value3: "",
      value4: "",
      pz: 0,
      jpall: "",
      param: "",
      mysrc: "",
      off: true, //控制参与活动，规则，我的奖品
      jp_off: false, //奖品面板
      gz_off: false //规则面板
    };
  },

  //组件
  components: {},

  //自定义方法
  methods: {
    jxj_quedingon() {
      if (this.value3.length < 1) {
        Toast("请输入姓名");
        return;
      }
      if (this.value4.length < 1) {
        Toast("请输入电话");
        return;
      }
      if (!this.cr.valiPhone(this.value4)) {
        Toast("请输入正确的电话号码");
        return;
      }
      if (this.scImg.length < 1) {
        Toast("请上传图片");
        return;
      }

      if (this.load) return;
      this.load = 1;

      this.cr.ajax({
        url: "image",
        data: {
          res_id: this.jpall[this.pzIdx].id,
          phone: this.value4,
          img_base64: this.scImg,
          name: this.value3
        },
        fn: res => {
          Toast(res.msg);

          if (res.code == 1) {
            setTimeout(() => {
              this.pz = 0;
              this.jpall[this.pzIdx].card = 1;
            }, 2000);
          } else {
            this.load = 0;
          }
        }
      });
    },
    bbb() {
      this.cr.upImg({
        fn: res => {
          this.scImg = res;
        }
      });
    },
    //点击规则
    gzclick() {
      this.off = false;
      this.gz_off = true;
    },
    //点击奖品
    jpclick() {
      this.off = false;
      this.jp_off = true;
      this.cr.ajax({
        url: "myprize",
        type: "post",
        data: {
          param: this.$store.state.p
        },
        fn: res => {
          if (res.code == 1) {
            this.jpall = res.myprize;
          } else {
            Toast(res.msg);
          }
        }
      });
    },
    //返回首页
    fhclick() {
      this.off = true;
      this.jp_off = false;
      this.gz_off = false;
    },
    changepage() {
      if (this.$store.state.dataInfo.user.job != undefined) {
        this.$store.state.idx = 3;
      } else {
        this.$store.state.idx = 2;
      }
    },
    changelq(id) {
      Dialog.confirm({
        title: "提示",
        message: "请确认为店员点击，消费者自行点击奖品失效，自行负责！"
      })
        .then(() => {
          this.cr.ajax({
            url: "receive",
            type: "post",
            data: {
              res_id: id
            },
            fn: res => {
              if (res.code == 1) {
                Toast("成功");
                document.getElementById(id).style.color = "#676767";
              } else {
                Toast(res.msg);
                // document.getElementById(id).style.color = "#676767";
              }
            }
          });
        })
        .catch(() => {
          // on cancel
        });
    }
  },

  //在实例创建完成后被立即调用
  created() {
    this.cr.ajax({
      url: "shop",
      data: {
        param: this.$store.state.p
      },
      fn: res => {
        if (res.code == 1) {
          this.mysrc = res.shop;
        } else {
          Toast(res.msg);
        }
      }
    });
  },

  // 离开页面清除滚动事件
  destroyed() {},

  //添加真实dom，不一定所有的子组件也都一起被挂载才回调
  mounted() {}
};
</script>

<style lang="less" scroped>
#load {
  position: absolute;
  top: -999px;
}

#home {
  position: relative;
  > .maxbox {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;

    > div {
      width: 4.63rem;
      position: absolute;
      top: 0.6rem;
      left: 1.64rem;
    }
    // .zimu{

    // }
    > .logo {
      animation: bounceInDown 1s backwards 0.1s;
    }
    > .titleclass {
      position: absolute;
      top: 2.1rem;
      left: 0.9rem;
      width: 6.02rem;
      z-index: 9;
      animation: flash 10s backwards infinite;
    }
    > .yueqiu {
      position: absolute;
      width: 6.99rem;
      height: 7.74rem;
      top: 3.05rem;
      left: 0.51rem;
      animation: fadeIn 1s backwards;
    }
    > .sekuai {
      width: 2.13rem;
      height: 1.88rem;
      position: absolute;
      top: 8.8rem;
      left: 5.36rem;
      animation: bounceInRight 1s backwards;
    }
    > .xiaoyueqiu {
      position: absolute;
      left: 2.6rem;
      top: 5rem;
      animation: xingqiumove 20s backwards infinite;
    }
    > .woman {
      width: 1.93rem;
      position: absolute;
      left: 1.5rem;
      top: 6rem;
      animation: fadeIn 1s backwards 1s;
    }
    > .man {
      width: 1.68rem;
      position: absolute;
      top: 5.9rem;
      left: 5rem;
      animation: fadeIn 1s backwards 0.5s;
    }
    > .keleclass {
      width: 0.98rem;
      top: 4.85rem;
      left: 3.8rem;
      position: absolute;
      animation: tada 2s backwards infinite;
    }
    > .bookclass {
      width: 1.06rem;
      position: absolute;
      top: 8.1rem;
      left: 0.6rem;
      animation: fadeIn 1s backwards 0.2s;
    }
    > .guangclass {
      width: 5rem;
      height: 4.94rem;
      position: absolute;
      top: 8.9rem;
      left: 0.2rem;
      z-index: 1;
    }
    > .cy-btn {
      width: 2.65rem;
      position: absolute;
      top: 11.4rem;
      left: 2.4rem;
      z-index: 9;
      animation: slideInUp 1s backwards 0.5s;
    }
    > .gz-btn {
      width: 2.65rem;
      position: absolute;
      top: 12.85rem;
      left: 0.55rem;
      z-index: 9;
      animation: slideInUp 1s backwards 1s;
    }
    > .jp-btn {
      width: 2.65rem;
      position: absolute;
      top: 12.85rem;
      left: 4.3rem;
      z-index: 9;
      animation: slideInUp 1s backwards 0.7s;
    }
    > .dibu {
      width: 7.5rem;
      position: absolute;
      top: 10.85rem;
      left: 0rem;
      z-index: 2;
    }
    > .heng2 {
      width: 6.46rem;
      position: absolute;
      top: 2.01rem;
      left: 0.5rem;
      z-index: 2;
    }
    > .src {
      width: 4.46rem;
      position: absolute;
      top: 10.5rem;
      left: 2rem;
      z-index: 2;
      color: #fff;
      font-size: 0.25rem;
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
      > .srcimg {
        width: 0.27rem;
        float: left;
      }
    }

    /*奖品界面*/
    > .jp {
      width: 6.28rem;
      height: 10.33rem;
      position: absolute;
      top: 2.25rem;
      left: 0.65rem;
      z-index: 999;
      background: url(../assets/image/jpkuang.png) no-repeat;
      background-size: 100% 100%;
      animation: bounceInDown 0.5s backwards 0.2s;
      > .maxdiv {
        width: 6rem;
        height: 6rem;
        overflow: auto;
        margin: 2rem auto;
        > .maxjp {
          width: 6rem;
          height: auto;
          display: flex;
          flex-wrap: wrap;
          > li {
            width: 1.5rem;
            height: 3rem;
            list-style: none;
            margin-left: 0.35rem;
            color: white;
            > .jp_name {
              width: 100%;
              float: left;
              > img {
                width: 1.45rem;
                height: 1.72rem;
              }
            }
            > .jp_zt {
              width: 100%;
              height: 0.35rem;
              font-size: 0.2rem;
              color: #fff;
              float: left;
              margin-top: 0.5rem;
              > p {
                width: 1rem;
                height: 0.35rem;
                margin: auto;
                border: 1px solid #fff;
                border-radius: 0.02rem;
                text-align: center;
              }
            }
          }
        }
      }
    }
    > .fh-btn {
      width: 2.65rem;
      position: absolute;
      top: 13rem;
      left: 2.5rem;
      z-index: 999;
      animation: bounceInUp 0.5s backwards 0.5s;
    }

    /*规则*/
    > .gz {
      width: 6.48rem;
      position: absolute;
      top: 2.25rem;
      left: 0.65rem;
      z-index: 999;
      animation: bounceInUp 0.5s backwards 0.2s;
    }
  }

  .pz {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.6);
    z-index: 1000;
  }
  .jzjxj {
    position: absolute;
    top: 2.12rem;
    left: 1.11rem;
    width: 5.3rem;
    height: 9.53rem;
    z-index: 9;
  }
  .vancell3 {
    width: 3.57rem;
    height: 0.72rem;
    position: absolute;
    top: 6.39rem;
    left: 2.45rem;
    z-index: 9;
  }
  .vancell4 {
    width: 3.57rem;
    height: 0.72rem;
    position: absolute;
    top: 7.51rem;
    left: 2.45rem;
    z-index: 9;
  }
  .flix {
    position: absolute;
    top: 8.82rem;
    left: 3.16rem;
    width: 2.24rem;
    height: 1.49rem;
    z-index: 9;

    img {
      height: 100%;
    }
  }
  .jxj_quedingon {
    width: 2.65rem;
    height: 0.99rem;
    position: absolute;
    top: 12.4rem;
    left: 2.43rem;
    z-index: 9;
  }

  .kuan {
    position: absolute;
    top: 0;
    left: 0;
    width: 90%;
  }
}
::-webkit-scrollbar {
  overflow: hidden;
}
.yuanclass {
  width: 6.99rem;
  height: 7.74rem;
  position: absolute;
  right: 0;
  top: 3.08rem;
}
.thisman {
  width: 1.68rem;
  height: 4.26rem;
  position: absolute;
  top: 5.86rem;
  left: 5rem;
}
@keyframes xingqiumove {
  0% {
    transform: rotate(0deg);
  }
  25% {
    transform: rotate(60deg);
  }
  50% {
    transform: rotate(120deg);
  }
  75% {
    transform: rotate(180deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
</style>


