<template>
  <div id="home2">
    <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/bg.png" alt />
    <div class="maxbox">
      <img src="../assets/image/baishilogo.png" alt />
      <div class="hengxian">
        <img src="../assets/image/hangxian.png" alt />
      </div>
      <div class="dibuaclass">
        <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/dibu.png" alt />
      </div>
      <div class="logoclass">
        <img src="../assets/image/logo.png" alt />
      </div>
      <div class="titleclass">
        <img src="../assets/image/title1.png" alt />
      </div>
      <div class="yueqiu">
        <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/yuan.png" alt />
      </div>
      <div class="sekuai">
        <img src="../assets/image/kuai.png" alt />
      </div>
      <div class="xiaoyueqiu">
        <img src="../assets/image/2-qiu.png" alt />
      </div>
      <div class="xiaowoman">
        <img src="../assets/image/miniwoman.png" alt />
      </div>
      <div class="xiaoman">
        <img src="../assets/image/miniman.png" alt />
      </div>
      <div class="bookclass">
        <img src="../assets/image/book.png" alt />
      </div>
      <div class="guangclass">
        <img src="../assets/image/guang.png" alt />
      </div>
      <div class="xiaoyueliang">
        <img src="../assets/image/xiaoyuan.png" alt />
      </div>
      <div class="jplist">
        <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/zhuanpan2.png" class="neiRong zp" :class="zt" :style="ks" />
      </div>
      <div class="zhuanpan-bain">
        <img src="../assets/image/zhuanpan-bian.png" />
      </div>
      <div class="kaishibtn">
        <img src="../assets/image/btn-kaishi.png" @click="kaishi" class="neiRong zz" />
      </div>
    </div>
    <div class="fh-btn" @click="$store.state.idx = 1">
      <img src="../assets/image/fh-btn.png" alt />
    </div>
    <!-- <div>
              <img src="../assets/image/yuan.png" alt="" class="yuanclass">
        </div>    
        
        <div>
            <img src="../assets/image/man.png" alt="" class="thisman">    
    </div>-->
    <div>
      <div v-show="zj2 == '雪盐焦糖中瓶'">
        <img src="../assets/image/mid-kuang.png" alt class="kuang mid" style="z-index:999" />

        <img src="../assets/image/gx-text.png" alt class="gxtext" style="z-index:999" />

        <img
          src="../assets/image/btn-queding.png"
          alt
          class="quedingbtn"
          @click="quedingon"
          style="z-index:999"
        />

        <img
          src="../assets/image/btn-yaoqing.png"
          alt
          class="yaoqingbtn"
          @click="showyaoqing"
          style="z-index:999"
        />

        <img src="../assets/image/mengban.png" alt class="mengbanclass" />

        <img src="../assets/image/zj-kele.png" alt class="zjkele" style="z-index:999" />
      </div>
    </div>

    <div>
      <!--   -->
      <div v-show="zj2 == '无糖树莓罐'">
        <img src="../assets/image/mid-kuang.png" alt class="kuang mid" style="z-index:999" />

        <img src="../assets/image/gx-text.png" alt class="gxtext" style="z-index:999" />

        <img
          src="../assets/image/btn-queding.png"
          alt
          class="quedingbtn"
          @click="quedingon"
          style="z-index:999"
        />

        <!-- <img
          src="../assets/image/btn-yaoqing.png"
          alt
          class="yaoqingbtn"
          @click="showyaoqing"
          style="z-index:999"
        /> -->

        <img src="../assets/image/mengban.png" alt class="mengbanclass" />

        <img
          src="../assets/image/zj-wutang.png"
          alt
          class="zjkele"
          style="z-index:999;width:2.48rem;height:3.36rem;left:2.5rem"
        />
      </div>
    </div>

    <div>
      <div v-show="zj2 == '续杯'">
        <img src="../assets/image/mid-kuang.png" alt class="kuang mid" style="z-index:999" />

        <img src="../assets/image/gx-text.png" alt class="gxtext" style="z-index:999" />

        <img
          src="../assets/image/btn-queding.png"
          alt
          class="quedingbtn"
          @click="quedingon"
          style="z-index:999"
        />

        <!-- <img
          src="../assets/image/btn-yaoqing.png"
          alt
          class="yaoqingbtn"
          @click="showyaoqing"
          style="z-index:999"
        /> -->

        <img src="../assets/image/mengban.png" alt class="mengbanclass" />

        <img src="../assets/image/zj-xubei.png" alt class="zjxubei" style="z-index:999" />
      </div>
    </div>
    <!-- v-show="zj2 == '尊享卡'" -->
    <div v-show="zj2 == '尊享卡'">
      <img src="../assets/image/zj-dekeshi.png" alt class="zjdekeshikuang" />
      <img src="../assets/image/btn-queding.png" alt class="zjquedingbtn" @click="jzqueren" />
      <div id="vancell">
        <van-cell-group>
          <van-field v-model="value" maxlength='11'/>
        </van-cell-group>
      </div>
      <div id="vancell2">
        <van-cell-group>
          <van-field v-model="value2" maxlength='11' />
        </van-cell-group>
      </div>

      <img src="../assets/image/mengban.png" alt class="mengbanclass" style="z-index:998" />
    </div>

    <!-- v-show="zj2 == '奖学金'" -->
    <div v-show="zj2 == '奖学金'">
      <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/zj-jiangxuejin.png" alt class="jzjxj" style="z-index:999" />
      <div id="cell3">
        <van-cell-group>
          <van-field v-model="value3"  maxlength='11'/>
        </van-cell-group>
      </div>
      <div id="cell4">
        <van-cell-group>
          <van-field v-model="value4"  maxlength='11'/>
        </van-cell-group>
      </div>

      <div @click="bbb" class="flix" style="z-index:999">
        <img src="../assets/image/flix.png" v-if="!scImg" />
        <img :src="scImg" v-else style="width:2.24rem;height: 1.49rem" />
      </div>
      <img
        src="../assets/image/btn-queding.png"
        alt
        class="jxj_quedingon"
        @click="jxj_quedingon"
        style="z-index:999"
      />
      <img src="../assets/image/mengban.png" alt class="mengbanclass" style="z-index:998" />
    </div>
    <div class="fenxiang" v-show="fenxiangshow" @click="fenxiangshow = 0 ">
      <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/fenxiang.png" alt />
    </div>

    <div v-show="isinfoCG">
      <img src="../assets/image/infoCG.png" alt class="infoCG" />

      <img src="../assets/image/btn-fanhui.png" alt class="huifananniu" @click="fanhuianniu" />

      <!-- <img src="../assets/image/btn-yaoqing.png" alt class="yaoqinganniu" @click="showyaoqing" /> -->

      <img src="../assets/image/mengban.png" alt class="mengbanclass" style="z-index:998" />
    </div>
  </div>
</template>

<script>
import Vue from "vue";
import { Toast } from "vant";
import { Field } from "vant";
import { Uploader } from "vant";
Vue.use(Toast, Field, Uploader);

export default {
  //定义数据
  data() {
    return {
      isinfoCG: false,
      iskuangshow: false,
      fenxiangshow: 0,
      value: "",
      value2: "",
      value3: "",
      value4: "",
      valueimg: "",
      res_id: "",
      tc: 0,
      load2: 0,
      load3: 0,
      zj2: "",
      zt: "",
      ks: "",
      scImg: "",
      data: {
        奖学金: 30,
        续杯: 110,
        无糖树莓罐: 150,
        尊享卡: 210,
        续杯: 270,
        雪盐焦糖中瓶: 330
      },
      type: 1
    };
  },

  //组件
  components: {},

  //自定义方法
  methods: {
    fanhuianniu() {
      this.isinfoCG = false;
    },
    showyaoqing() {
      this.fenxiangshow = true;
      this.isinfoCG = false;
      document.body.scrollTop = document.documentElement.scrollTop = 0;
    },
    jxj_quedingon() {
      if (this.value3.length < 1) {
        Toast("请输入姓名");
        return;
      }
      if (this.value4.length < 1) {
        Toast("请输入电话");
        return;
      }
      if (!this.cr.valiPhone(this.value4)) {
        Toast("请输入正确的电话号码");
        return;
      }
      if (this.scImg.length < 1) {
        Toast("请上传图片");
        return;
      }

      if (this.load2) return;
      this.load2 = 1;

      this.cr.ajax({
        url: "image",
        data: {
          res_id: this.res_id,
          phone: this.value4,
          img_base64: this.scImg,
          name: this.value3
        },
        fn: res => {
          Toast(res.msg);
          if (res.code == 1) {
            this.zj2 = false;
            this.isinfoCG = true;
          } else {
            this.load2 = 0;
          }
        }
      });
    },
    bbb() {
      this.cr.upImg({
        fn: res => {
          this.scImg = res;
          console.log(this.valueimg);
        }
      });
    },
    drag(el) {
      console.log(el);
    },
    quedingon() {
      this.zj2 = false;
      Toast("奖品已放入 首页>我的奖品中");
    },
    jieguo(t) {
      if (t == "谢谢参与") {
      } else {
      }

      this.load2 = 0;
    },

    kaishi() {
      console.log(this.$store.state.dataInfo.re_num);
      if (this.$store.state.dataInfo.re_num >= 2) {
        Toast("今日暂无次数");
        return;
      }

      if (this.load3) return;
      this.load3 = 1;

      this.cr.ajax({
        url: "draw",
        data: {
          param: this.$store.state.p
        },
        fn: res => {
          if (res.code == 1) {
            var zj = res.rid;
            this.$store.state.dataInfo.re_num++;
            this.ks = "";
            this.zt = "gddh";
            this.jieshu(zj);
            this.res_id = res.res_id;
            setTimeout(() => {
              this.load3 = 0;
              this.zj2 = res.rid;
            }, 6000);
          } else {
            Toast(res.msg);
            this.load3 = 0;
          }
        }
      });
    },

    jieshu(rid) {
      setTimeout(() => {
        this.zt = "";
        setTimeout(() => {
          let _j = this.data[rid];
          let _r = 360 * 3 + _j;
          let _s = 0.6 * (4 + _j / 360);
          this.ks =
            "transform: rotate(" +
            _r +
            "deg);transition: all " +
            _s +
            "s ease-out;";
          setTimeout(() => {
            this.jieguo(rid);
            setTimeout(() => {
              this.iskuangshow = true;
            }, 500);
          }, (_s + 0.2) * 1000);
        }, 18);
      }, 2400);
    },
    jzqueren() {
      if (this.value3.length < 1) {
        Toast("请输入姓名");
        return;
      }
      if (this.value4.length < 1) {
        Toast("请输入电话");
        return;
      }
      if (!this.cr.valiPhone(this.value4)) {
        Toast("请输入正确的电话号码");
        return;
      }
      this.cr.ajax({
        url: "info1",
        data: {
          name: this.value,
          phone: this.value2
        },
        fn: res => {
          if (res.code == 1) {
            this.zj2 = false;
            Toast("提交成功");
          } else {
            Toast(res.msg);
          }
        }
      });
    },
    isfenxiangshow() {}
  },

  //在实例创建-=完成后被立即调用
  created() {},

  // 离开页面清除滚动事件
  destroyed() {},

  //添加真实dom，不一定所有的子组件也都一起被挂载才回调
  mounted() {}
};
</script>

<style lang="less" scroped>
.huifananniu {
  position: absolute;
  top: 9.39rem;
  left: 2.5rem;
  width: 2.65rem;
  height: 0.99rem;
  z-index: 999;
}
.yaoqinganniu {
  position: absolute;
  width: 2.65rem;
  height: 0.99rem;
  z-index: 999;
  top: 9.39rem;
  left: 4.17rem;
}
.infoCG {
  position: absolute;
  top: 4.21rem;
  left: 1.11rem;
  width: 5.3rem;
  height: 4.26rem;
  z-index: 999;
}

.jxj_quedingon {
  width: 2.65rem;
  height: 0.99rem;
  position: absolute;
  top: 12.4rem;
  left: 2.43rem;
  z-index: 9;
}
.flix {
  position: absolute;
  top: 8.82rem;
  left: 3.16rem;
  width: 2.24rem;
  height: 1.49rem;
  z-index: 9;
}
.zjxubei {
  position: absolute;
  top: 5.45rem;
  left: 2.23rem;
  width: 3rem;
  height: 2.4rem;
  z-index: 200;
}
.fenxiang {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 1000;
}
.jzjxj {
  position: absolute;
  top: 2.12rem;
  left: 1.11rem;
  width: 5.3rem;
  height: 9.53rem;
  z-index: 999;
}
.mengbanclass {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 998;
}
#vancell {
  width: 3.57rem;
  height: 0.72rem;
  position: absolute;
  top: 7.59rem;
  left: 2.45rem;
  z-index: 9999;
}
#vancell2 {
  width: 3.57rem;
  height: 0.72rem;
  position: absolute;
  top: 8.71rem;
  left: 2.45rem;
  z-index: 9999;
}
#cell3 {
  width: 3.57rem;
  height: 0.72rem;
  position: absolute;
  top: 6.39rem;
  left: 2.45rem;
  z-index: 9999;
}
#cell4 {
  width: 3.57rem;
  height: 0.72rem;
  position: absolute;
  top: 7.51rem;
  left: 2.45rem;
  z-index: 9999;
}

.zp {
  &.gddh {
    animation: zhuanQuan 0.4s linear infinite;
  }
}
.xm {
  animation: fadeIn 1s backwards;
}
#load {
  position: absolute;
  top: -999px;
}
.zjquedingbtn {
  width: 2.65rem;
  height: 0.99rem;
  position: absolute;
  top: 10.59rem;
  left: 2.43rem;
  z-index: 999;
}
.zjdekeshikuang {
  width: 5.3rem;
  height: 7.33rem;
  position: absolute;
  top: 2.62rem;
  left: 1.11rem;
  z-index: 999;
}
#home2 {
  position: relative;
  > .maxbox {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;

    > div {
      width: 4.63rem;
      height: 0.89rem;
      position: absolute;
      top: 0.7rem;
      left: 1.64rem;
    }
    > .dibuaclass {
      width: 7.5rem;
      position: absolute;
      left: 0;
      top: 10.8rem;
      z-index: 3;
    }
    > .titleclass {
      position: absolute;
      top: 2.19rem;
      left: 2rem;
      width: 3.6rem;
      height: 1.25rem;
      z-index: 2;
      animation: jackInTheBox 1s backwards 1s;
    }
    > .logoclass {
      z-index: 2;
      animation: zoomInUp 1s backwards;
    }
    > .yueqiu {
      position: absolute;
      width: 6.99rem;
      height: 7.74rem;
      top: 3.05rem;
      left: 0.51rem;
      z-index: 1;
    }
    > .kaishibtn {
      position: absolute;
      width: 2.41rem;
      height: 2.56rem;
      z-index: 7;
      top: 6.59rem;
      left: 2.69rem;
      animation: zoomIn 2s backwards 1s;
    }
    > .sekuai {
      width: 2.13rem;
      height: 1.88rem;
      position: absolute;
      top: 9.31rem;
      left: 5.36rem;
      z-index: 2;
    }
    > .xiaoyueqiu {
      position: absolute;
      left: 2.2rem;
      top: 5.7rem;
      z-index: 2;
    }
    > .jplist {
      position: absolute;
      top: 4.95rem;
      left: 0.93rem;
      z-index: 6;
      width: 5.91rem;
      height: 5.91rem;
      // transform: rotate(90deg)
      animation: zoomIn 2s backwards 0.5s;
    }
    > .xiaowoman {
      width: 1.66rem;
      height: 3.48rem;
      position: absolute;
      left: 0.77rem;
      top: 10.7rem;
      z-index: 99;
      animation: fadeInLeftBig 2s backwards;
    }
    > .xiaoman {
      width: 1.43rem;
      height: 3.63rem;
      position: absolute;
      top: 10.06rem;
      left: 5.81rem;
      z-index: 99;
      animation: fadeIn 2s backwards 1s;
    }
    > .bookclass {
      width: 0.8rem;
      height: 1.55rem;
      position: absolute;
      top: 12.44rem;
      left: 0.23rem;
      z-index: 4;
    }
    > .guangclass {
      width: 5rem;
      height: 4.94rem;
      position: absolute;
      top: 9.3rem;
      left: 0.37rem;
      z-index: 1;
      animation: fadeIn 10s backwards;
    }
    > .hengxian {
      position: absolute;
      top: 2.84rem;
      left: 6.27rem;
      width: 0.76rem;
      height: 1.02rem;
      z-index: 2;
    }
    > .xiaoyueliang {
      position: absolute;
      top: 0;
      width: 2.39rem;
      height: 2.19rem;
      z-index: 1;
      opacity: 0.8;
      left: 5.24rem;
      animation: bounceInRight 2s backwards;
    }
    > .zhuanpan-bain {
      position: absolute;
      top: 4.73rem;
      left: 0.7rem;
      z-index: 3;
      width: 6.36rem;
      height: 6.36rem;
      animation: zoomIn 2s backwards;
    }
  }
}

.yuanclass {
  width: 6.99rem;
  height: 7.74rem;
  position: absolute;
  right: 0;
  top: 3.08rem;
}
.thisman {
  width: 1.68rem;
  height: 4.26rem;
  position: absolute;
  top: 5.86rem;
  left: 5rem;
}
.mid {
  position: absolute;
  top: 3.52rem;
  left: 1.11rem;
  width: 5.3rem;
  height: 5.33rem;
  z-index: 101;
  animation: jello 1s backwards;
}
.gxtext {
  position: absolute;
  top: 3.85rem;
  left: 2.23rem;
  width: 3.05rem;
  height: 0.82rem;
  z-index: 102;
  animation: jello 1s backwards;
}
.quedingbtn,
.yaoqingbtn {
  position: absolute;
  top: 9.49rem;
  left: 2.5rem;
  width: 2.65rem;
  height: 0.99rem;
  z-index: 103;
  animation: bounceInLeft 1s backwards 1s;
}
.yaoqingbtn.btn:hover,
.yaoqingbtn.btn:focus {
  animation: gelatine 1s 1;
}
.yaoqingbtn {
  left: 4.29rem;
  animation: bounceInRight 1s backwards 1s;
}
.zjkele {
  position: absolute;
  top: 5.02rem;
  left: 2.8rem;
  width: 1.89rem;
  height: 3.32rem;
  z-index: 200;
}
.fh-btn {
  width: 2.65rem;
  position: absolute;
  top: 13rem;
  left: 2.5rem;
  z-index: 99;
}
</style>


