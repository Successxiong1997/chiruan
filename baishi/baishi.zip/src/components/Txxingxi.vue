<template>
  <div id="home">
    <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/bg.png" alt />
    <div class="maxbox">
      <img src="../assets/image/baishilogo.png" alt />
      <div>
        <img src="../assets/image/logo.png" alt />
      </div>
      <div class="titleclass">
        <img src="../assets/image/title.png" alt />
      </div>
      <div class="yueqiu">
        <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/yuan.png" alt />
      </div>
      <div class="sekuai">
        <img src="../assets/image/kuai.png" alt />
      </div>
      <div class="xiaoyueqiu">
        <img src="../assets/image/2-qiu.png" alt />
      </div>
      <div class="woman">
        <img src="../assets/image/woman.png" alt />
      </div>
      <div class="man">
        <img src="../assets/image/man.png" alt />
      </div>
      <div class="keleclass">
        <img src="../assets/image/kele.png" alt />
      </div>
      <div class="bookclass">
        <img src="../assets/image/book.png" alt />
      </div>
      <div class="guangclass">
        <img src="../assets/image/guang.png" alt />
      </div>
      <div class="dibu">
        <img src="https://img.chiruan.net/vueCode/ruigead/zlxxz/static/img/dibu.png" alt />
      </div>
      <div class="heng2">
        <img src="../assets/image/heng2.png" alt />
      </div>
      <div class="txxx">
        <img src="../assets/image/info.png" alt />
      </div>
      <div class="txxx">
        <img src="../assets/image/info.png" alt />
      </div>
      <div class="set">
        职业&nbsp;&nbsp;
        <select>
          <option>{{xuesheng}}</option>
          <option>其他</option>
        </select>
      </div>
      <div class="qr-btn" @click="qrinfo">
        <!-- $store.state.idx = 3; -->
        <img src="../assets/image/qr-btn.png" alt />
      </div>
    </div>
    <!-- <div>
              <img src="../assets/image/yuan.png" alt="" class="yuanclass">
        </div>    
        
        <div>
            <img src="../assets/image/man.png" alt="" class="thisman">    
    </div>-->
  </div>
</template>

<script>
export default {
  //定义数据
  data() {
    return {
      xuesheng:'学生',
      load: 0
    };
  },

  //组件
  components: {},

  //自定义方法
  methods: {
    qrinfo() {
      this.cr.ajax({
        url: "info",
        data: {
          job:this.xuesheng
        },
        fn: res => {
          if (res.code == 1) {
            this.$store.state.idx = 3;
          } else {
            Toast(res.msg);
            this.load = 0;
          }
        }
      });
    }
    // aaa(){
    //     if(this.load == 1) return;
    //     this.load = 1;
    //     let job = 'sss'
    //     this.cr.ajax({
    //         url: 'info',
    //         data: {
    //             job: job
    //         },
    //         fn: (res)=> {
    //             this.$vux.toast.hide();
    //             if(res.code == 1){
    //               this.$store.state.idx = 3;
    //             }else{
    //               this.cr.tip(res.msg)
    //               this.load = 0;
    //             }
    //         }
    //     })
    // }
  },

  //在实例创建完成后被立即调用
  created() {},

  // 离开页面清除滚动事件
  destroyed() {},

  //添加真实dom，不一定所有的子组件也都一起被挂载才回调
  mounted() {}
};
</script>

<style lang="less" scroped>
#load {
  position: absolute;
  top: -999px;
}

#home {
  position: relative;
  > .maxbox {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;

    > div {
      width: 4.63rem;
      position: absolute;
      top: 0.6rem;
      left: 1.64rem;
    }
    > .titleclass {
      position: absolute;
      top: 2rem;
      left: 0.9rem;
      width: 6.02rem;
      z-index: 9;
    }
    > .yueqiu {
      position: absolute;
      width: 6.99rem;
      height: 7.74rem;
      top: 3.05rem;
      left: 0.51rem;
    }
    > .sekuai {
      width: 2.13rem;
      height: 1.88rem;
      position: absolute;
      top: 8.8rem;
      left: 5.36rem;
    }
    > .xiaoyueqiu {
      position: absolute;
      left: 2.6rem;
      top: 5rem;
    }
    > .woman {
      width: 1.93rem;
      position: absolute;
      left: 1.5rem;
      top: 6rem;
    }
    > .man {
      width: 1.68rem;
      position: absolute;
      top: 5.9rem;
      left: 5rem;
    }
    > .keleclass {
      width: 0.98rem;
      top: 4.85rem;
      left: 3.8rem;
      position: absolute;
    }
    > .bookclass {
      width: 1.06rem;
      position: absolute;
      top: 8.1rem;
      left: 0.6rem;
    }
    > .guangclass {
      width: 5rem;
      height: 4.94rem;
      position: absolute;
      top: 9.5rem;
      left: 0.4rem;
      z-index: 1;
    }
    > .dibu {
      width: 7.5rem;
      position: absolute;
      top: 10.85rem;
      left: 0rem;
      z-index: 2;
    }
    > .heng2 {
      width: 6.46rem;
      position: absolute;
      top: 2.01rem;
      left: 0.5rem;
      z-index: 2;
    }
    > .txxx {
      width: 2.44rem;
      position: absolute;
      top: 10.1rem;
      left: 2.5rem;
      z-index: 99;
    }
    > .set {
      width: auto;
      position: absolute;
      top: 11.3rem;
      left: 1rem;
      z-index: 99;
      color: #fff;
      font-size: 0.35rem;
      > select {
        width: 4.5rem;
        height: 0.7rem;
        > option {
          border-bottom: 1px solid #000;
        }
      }
    }
    > .qr-btn {
      width: 2.65rem;
      position: absolute;
      top: 12.7rem;
      left: 2.5rem;
      z-index: 99;
    }
  }
}

.yuanclass {
  width: 6.99rem;
  height: 7.74rem;
  position: absolute;
  right: 0;
  top: 3.08rem;
}
.thisman {
  width: 1.68rem;
  height: 4.26rem;
  position: absolute;
  top: 5.86rem;
  left: 5rem;
}
</style>


