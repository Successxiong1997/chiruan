import Wx from './Wx'
import myAjax from './Ajax'
import vali from './vali'
import upImg from './upImg'
// import Vue from 'vue'

const cr = {
    /**
     *
     *  ajax
     *
     */
    ajax(opts) {
        if(opts.load){
            Vue.$vux.loading.show({
                text: opts.load
            })
        }

        myAjax(opts);
    },

    /**
     *
     *  微信分享配置
     *
     */
    share(opts) {
        Wx.shareConfig(opts)
    },

    /**
     *
     *  提示
     *
     */
    tip(txt) {
        Vue.$vux.toast.show({
            type             : 'text',
            text             : txt,
            showPositionValue: false,     //是否显示提示
            position         : 'middle',  //提示信息的位置
            toastText        : '',        //提示文本
            width            : txt.length + 1 + ".6em"
        })
    },


    /**
     *
     *  验证
     *
     */
    ...vali,



    //随机
    sum(m,n){
    　　return Math.floor(Math.random()*(m - n) + n);
    },


    /**
     * 
     * 上传
     * 
     */
    upImg(fn){
        upImg(fn,Vue.$vux,this)
    },


    //回到顶部
    dingbu(){
        document.body.scrollTop = document.documentElement.scrollTop = 0;
    }
}

/**
 *
 *  暴露方法
 *
 */
export default {
    install (vue) {
        vue.cr = cr;
        vue.mixin({
            created: function () {
                this.cr = cr
            }
        })
    }
}
