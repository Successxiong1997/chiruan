// import axios from "axios";
import config from '../config.json'
// import router from '../../router'

//ajax
const ajax = (opts) => {
    let _data = opts.data||{};
    // let _txt  = "";
    let _form = new FormData();

    Object.keys(_data).forEach(function(key){
        _form.append(key,_data[key]);
        // _txt += ("&" + key + "=" + _data[key])
    });

    //超时
    let CancelToken = axios.CancelToken;
    let source = CancelToken.source();
    let chaoshi = setTimeout(()=>{
        source.cancel("chaoshi");
    },31000)

    axios({
        url         : opts.curl || (config.ajaxUrl + opts.url),
        method      : opts.type||'POST',
        data        : _form,//_txt.slice(1),
        ...opts.type == "get" ?  {params: _data} : {},
        responseType: 'json',
        cancelToken : source.token,
        // headers     : {
        //     'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        // }
    }).then((res) => {
        //清除超时
        clearTimeout(chaoshi);

        let _data = res.data;

        //判断是否是对象
        if(typeof(_data) != "object"){
            _data = JSON.parse(_data);
        }

        //判断是否授权失败，过期
       
        if(_data.code == 1000){
            //location.href = config.ajaxUrl + "?url=" + config.luyou + "&param=";
        }else{
            opts.fn(_data)
        }
    }).catch(function (error) {
        console.log(error)

        opts.er && opts.er(error);
    });
}

export default ajax
