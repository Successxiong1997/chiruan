// import axios from "axios";
// import router from '../../router'
// import config from '../config.json'
import exif from 'exif-js'

const rotateImg = (img, direction,canvas) => {    
    //最小与最大旋转方向，图片旋转4次后回到原方向    
    let min_step = 0;    
    let max_step = 3;    
  
    if (img == null)return; 

    let height = img.height;    
    let width = img.width;   
    
    let docW = document.documentElement.clientWidth;
    let docH = Math.ceil(docW * (height / width));

    img.height = height = docH;
    img.width = width = docW;

    let step = 2;    

       
    if (direction == 'no') {    
        step = 0;    
    } else if (direction == 'fz') {    
        step = 4;     
    } else if (direction == 'right') {    
        step++;    
        //旋转到原位置，即超过最大值    
        step > max_step && (step = min_step);    
    } else {    
        step--;    
        step < min_step && (step = max_step);    
    }   

    //旋转角度以弧度值为参数    
    let degree = step * 90 * Math.PI / 180;   
    let ctx = canvas.getContext('2d');    
    switch (step) {    
        case 0:    
            canvas.width = width;    
            canvas.height = height;     
            ctx.drawImage(img, 0, 0,docW,docH);    
            break;    
        case 1:    
            canvas.width = height;   
            canvas.height = width;    
            ctx.rotate(degree);    
            ctx.drawImage(img, 0, -height,docW,docH);  
            break;    
        case 2:    
            canvas.width = width;    
            canvas.height = height;      
            ctx.rotate(degree);    
            ctx.drawImage(img, -width, -height,docW,docH);  
            break;    
        case 3:    
            canvas.width = height;    
            canvas.height = width;       
            ctx.rotate(degree);    
            ctx.drawImage(img, -width, 0,docW,docH);    
            break;
        case 4:    
            canvas.width = width;    
            canvas.height = height; 
            ctx.rotate(3 * 180 * Math.PI / 180);        
            ctx.drawImage(img, -width, -height,docW,docH);     
            break;    
    }  
} 

//ajax
const upImg = (opts,vux,cr) => {

    let _id  = document.getElementById('file');
    let ipt  = document.createElement("input");
    let body = document.body;

    //删除上个ipt
    if(_id) _id.remove();

    //ipt添加属性
    ipt.type = ipt.name = ipt.id = "file";
    ipt.setAttribute('multiple',"multiple");
    ipt.setAttribute('accept',"image/*");

    //ipt添加到body
    body.appendChild(ipt);

    //监听事件
    ipt.onchange = (e) => {
        vux.loading.show({
            text: "图片上传中..."
        })

        let file = e.target.files[0];  
        let Orientation = null;
 
        if (!/\.(gif|jpg|jpeg|png|bmp|GIF|JPG|PNG)$/.test(e.target.value)) { 
            cr.tip('图片类型必须是.gif,jpeg,jpg,png,bmp中的一种');
            return false;
        } 
    
        exif.getData(file, function () {
            exif.getAllTags(this)
            Orientation = exif.getTag(this, 'Orientation');
        })

        //canvas转base64方法
        let fileReader = new FileReader();
        fileReader.onloadend = (e) => {
            
            // 这里的base64就是我们所要的 e.target.result;   
            if(!opts.url){

                let image = new Image();  
                image.src = e.target.result;  
                
                image.onload = function() {  
                    let canvas = document.createElement("canvas");  
                    //如果方向角不为1，都需要进行旋转 added by lzk  
                    if(Orientation != "" && Orientation != 1){   
                        switch(Orientation){  
                            case 6://需要顺时针（向左）90度旋转  
                                rotateImg(this,'left',canvas);  
                                break;  
                            case 8://需要逆时针（向右）90度旋转  
                                rotateImg(this,'right',canvas);  
                                break;  
                            case 3://需要180度旋转  
                                rotateImg(this,'fz',canvas);//转两次  
                                // rotateImg(this,'right',canvas);  
                                break; 
                            default:
                                rotateImg(this,'no',canvas);
                                break; 
                                 
                        }         
                    }else{
                        rotateImg(this,'no',canvas);
                    }

                    vux.loading.hide();

                    opts.fn(canvas.toDataURL("image/png",.7));
                };
            }
        };
        fileReader.readAsDataURL(file);
    }

    //出发点击
    ipt.click();
}

export default upImg
