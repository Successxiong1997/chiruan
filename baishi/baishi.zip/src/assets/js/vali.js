const vali = {
    /**
     *  获取值
     */
    valiVal: function (opts) {
        //return typeof opts === 'object'?opts.val().trim()||opts.html().trim():opts.trim();

        return (opts+"").trim() || "";
    },

    /**
     * 
     *   手机验证
     * 
     */
    valiPhone(opts) {
        opts = this.valiVal(opts);
        var $phe = /^(0|86|17951)?(1[1-9])[0-9]{9}$/;
        var $phe2 = /^((0\d{2,3})(-?))?(\d{7,8})(-(\d{3,}))?$/;
        if (!($phe.test(opts) || $phe2.test(opts))) {
           // this.tip('请输入正确的电话号码');
            return false;
        }
        return opts
    },

    /**
     * 
     *   手机验证
     * 
     */
    valiName(opts) {
        opts = this.valiVal(opts);
        var $name = /^([\u4e00-\u9fa5]){2,7}$/;
        if (!$name.test(opts)) {
            this.tip('请输入正确的姓名');
            return false;
        }
        return opts
    },

    /**
     * 
     *   手机验证
     * 
     */
    valiEmail: function (opts) {
        opts = this.valiVal(opts);
        var $eml = /\w+((-w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+/;
        if (!$eml.test(opts)) {
            this.tip('请输入正确的邮箱');
            return false;
        }
        return opts
    },

    /**
     * 
     *   手机验证
     * 
     */
    valiSFZ: function (opts) {
        opts = this.valiVal(opts);
        if (opts.length == 18) {
            opts = opts.split('');
            //∑(ai×Wi)(mod 11)
            //加权因子
            var $factor = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
            //校验位
            var $parity = [1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2];
            var $sum = 0;
            var $ai = 0;
            var $wi = 0;
            for (var i = 0; i < 17; i++) {
                $ai = opts[i];
                $wi = $factor[i];
                $sum += $ai * $wi;
            }
            var $last = $parity[$sum % 11];
            if ($last != opts[17]) {
                this.tip('请输入正确的身份证');
                return false;
            } else return opts.join("");
        } else {
            this.tip('请输入正确的身份证');
            return false;
        }
    }
}

/**
 * 
 *  暴露方法
 * 
 */
export default vali