import myAjax from './Ajax'
import config from '../config.json'

const Wx = {
    //配置
    is_wx    : null,
    jsApiList: ['checkJsApi','onMenuShareTimeline','onMenuShareAppMessage','onMenuShareQQ','onMenuShareWeibo'],
    debug    : false,
    wxId     : null,

    /**
     * 
     *   请求分享数据
     * 
     */
    shareConfig (opts) {
        opts = opts || {};
        opts.data = opts.data || {};
        opts.data.url = location.href;
        opts.data.share_url = opts.data.shareUrl || config.shareUrl;
        opts.data.project_id = opts.projectId;
        this.wxId = opts.wxId || this.wxId;
        this.projectId = opts.projectId;
        opts.data.js='vueCode';

        myAjax({
            curl : config.shareUrl + "vue_extra/share",
            type: "get",
            data: opts.data,
            fn  : (res) => {
                this.addJssdk(res, () => {
                    let _data = {
                        "title" : res.sign_package.share_title,
                        "desc"  : res.sign_package.share_desc,
                        "link"  : res.sign_package.share_url,
                        "imgUrl": res.sign_package.share_img
                    };
                    document.getElementsByTagName("title")[0].innerHTML = res.sign_package.title;
                    // 朋友圈
                    window["wx"].onMenuShareTimeline({
                        ..._data,
                        "success": ()=> {
                            this.shareCG(2,opts)
                        }
                    });
                    // 朋友
                    window["wx"].onMenuShareAppMessage({
                        ..._data,
                        "success": ()=> {
                            this.shareCG(1,opts)
                        }
                    });
                    // QQ
                    window["wx"].onMenuShareQQ({
                        ..._data,
                        "success": ()=> {
                            this.shareCG(3,opts)
                        }
                    });
                    // 微博
                    window["wx"].onMenuShareWeibo({
                        ..._data,
                        "success":()=> {
                            this.shareCG(4,opts)
                        }
                    });
                })
            }
        });
    },

    /**
     * 
     *   分享成功
     * 
     */
    shareCG(type,opts){
        myAjax({
            curl: config.shareUrl + "wechat/share",
            type: "post",
            data: {
                type : type,
                wx_info_id: this.wxId,
                project_id: this.projectId
            },
            fn  : (res) => {
                opts.fn && opts.fn(res,type);
            }
        }); 
    },

    /**
     * 
     *   加载微信jssdk
     * 
     */
    addJssdk(res,fn) {
        if(!this.is_wx){
            let script = document.createElement('script');

            this.is_wx = 1;
            script.src = "https://res.wx.qq.com/open/js/jweixin-1.0.0.js";
            document.body.appendChild(script);
            script.addEventListener('load',()=>{
                this.onLoadWeiXinJssdk(res,fn);
            },false);
        }else{
            this.onLoadWeiXinJssdk(res,fn);
        }
    },

    /**
     * 
     *  jssdk加载完成
     * 
     */
    onLoadWeiXinJssdk(res,fn){
        let wx = window["wx"];

        wx.config({
            "debug"    : this.debug,
            "appId"    : res.sign_package["appId"],
            "timestamp": res.sign_package["timestamp"],
            "nonceStr" : res.sign_package["nonceStr"],
            "signature": res.sign_package["signature"],
            "jsApiList": this.jsApiList
        });

        wx.ready(()=> {
            wx.checkJsApi({
                "jsApiList": this.jsApiList,
                "success"  : ()=> {
                    fn();
                }
            });
        });

        wx.error((err)=> {
            console.log("wx.error: " + JSON.stringify(err));
        });
    }

};

export default Wx


