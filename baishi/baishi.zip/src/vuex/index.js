// import Vue from 'vue'
// import Vuex from 'vuex'
// Vue.use(Vuex)




const store = new Vuex.Store({
    //数据存放  调用方法this.$store.state.dataInfo
    state: {
        //进页面请求接口的数据
        dataInfo: {},
        idx: 0,
        p:location.href.split("/#/")[1]
    },

    //类似vue的computed 计算属性  调用方法this.$store.getters.aaa
    getters: {

    },

    //方法定义  调用方法this.$store.commit('aaa')
    mutations: {
        //新的数据
        xdata(state,fn){
            Vue.cr.ajax({
                url : 'data',
                type: "get",
                fn: (res)=> {
                    if (res.code != 1) return;
                    let _data = res.data;
                    state.dataInfo = _data;
                    fn && fn(_data);
                }
            })
        }
    },

    //类似vue的mothods  调用方法this.$store.dispatch('aaa')
    actions: {

    }
})


export default store;