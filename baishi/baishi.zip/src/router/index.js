// import Vue from 'vue'
// import Router from 'vue-router'

// Vue.use(Router)
// const rq = require;

// export default new VueRouter({
//     routes: [
//         {
//             path: '/',
//             name: 'Main1',
//             component: r => rq.ensure([],()=>r(rq("@/components/Main1")), "Main1"),
//             meta: {
//                 keepAlive: true
//             }
//         },
//         {
//             path: '/noPrize',
//             name: 'Main2',
//             component: r => rq.ensure([],()=>r(rq("@/components/Main2")), "Main2"),
//             meta: {
//                 keepAlive: true
//             }
//         }      
//     ]
// })

